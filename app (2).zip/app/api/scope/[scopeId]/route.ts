import { NextResponse } from "next/server";
import mongoose from "mongoose";

import { connectToDB } from "@/lib/db";
import { requireUserId } from "@/lib/auth";
import ScopeDoc from "@/models/ScopeDoc";
import { serializeMongo } from "@/lib/serialize";

type Ctx = {
  params: Promise<{ scopeId: string }>;
};

export async function GET(_req: Request, { params }: Ctx) {
  const { userId, error } = requireUserId();
  if (error) return error;

  const { scopeId } = await params;

  if (!mongoose.Types.ObjectId.isValid(scopeId)) {
    return NextResponse.json({ error: "Invalid scope id" }, { status: 400 });
  }

  await connectToDB();

  const doc = await ScopeDoc.findOne({ _id: scopeId, userId });

  if (!doc) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  // IMPORTANT: convert to plain object before serializing
  const plain = doc.toObject();

  return NextResponse.json({
    scopeDoc: serializeMongo(plain),
  });
}
