// "use client";

// import { useState } from "react";

// export default function ScopeEditor({
//   scopeId,
//   initialGeneratedJson,
//   initialEditedJson,
// }: {
//   scopeId: string;
//   initialGeneratedJson: any;
//   initialEditedJson: any;
// }) {
//   const [view, setView] = useState<"generated" | "edited">("generated");

//   const data = view === "generated" ? initialGeneratedJson : initialEditedJson;

//   if (!data) {
//     return (
//       <div className="p-12 text-center text-zinc-400">
//         No scope document found.
//       </div>
//     );
//   }

//   function Section({
//     title,
//     children,
//   }: {
//     title: string;
//     children: React.ReactNode;
//   }) {
//     return (
//       <div className="mb-8">
//         <h2 className="text-xl font-semibold text-indigo-600 mb-3">{title}</h2>
//         <div className="bg-white rounded-lg shadow-sm border p-5">
//           {children}
//         </div>
//       </div>
//     );
//   }

//   function List({ items }: { items?: string[] }) {
//     if (!items?.length) return <p className="text-zinc-500">None</p>;
//     return (
//       <ul className="list-disc pl-5 space-y-1">
//         {items.map((i, idx) => (
//           <li key={idx}>{i}</li>
//         ))}
//       </ul>
//     );
//   }

//   return (
//     <div className="min-h-screen bg-zinc-950 text-zinc-900">
//       <div className="max-w-5xl mx-auto py-12 px-6">
//         <div className="flex items-center justify-between mb-10">
//           <div>
//             <h1 className="text-3xl font-bold text-white">
//               {data.projectTitle}
//             </h1>
//             <p className="text-zinc-400 mt-1">Scope ID: {scopeId}</p>
//           </div>

//           <div className="flex gap-2">
//             <button
//               onClick={() => setView("generated")}
//               className={`px-4 py-2 rounded ${
//                 view === "generated"
//                   ? "bg-indigo-600 text-white"
//                   : "bg-zinc-800 text-zinc-300"
//               }`}
//             >
//               Generated
//             </button>
//             <button
//               onClick={() => setView("edited")}
//               className={`px-4 py-2 rounded ${
//                 view === "edited"
//                   ? "bg-indigo-600 text-white"
//                   : "bg-zinc-800 text-zinc-300"
//               }`}
//             >
//               Edited
//             </button>
//           </div>
//         </div>

//         <Section title="Executive Summary">
//           <p>{data.executiveSummary}</p>
//         </Section>

//         <Section title="Problem Statement">
//           <p>{data.problemStatement}</p>
//         </Section>

//         <Section title="Goals">
//           <List items={data.goals} />
//         </Section>

//         <Section title="MVP Features">
//           <List items={data.mvp?.features} />
//         </Section>

//         <Section title="Phase 2">
//           <List items={data.phase2?.features} />
//         </Section>

//         <Section title="Timeline">
//           <div className="space-y-4">
//             {data.timeline?.map((t: any, i: number) => (
//               <div key={i} className="border rounded p-4">
//                 <div className="font-semibold">
//                   {t.phase} ({t.durationWeeks} weeks)
//                 </div>
//                 <List items={t.whatHappens} />
//               </div>
//             ))}
//           </div>
//         </Section>

//         <Section title="Risks">
//           <div className="space-y-3">
//             {data.risks?.map((r: any, i: number) => (
//               <div key={i} className="border rounded p-4">
//                 <div className="font-semibold">{r.risk}</div>
//                 <div className="text-sm text-zinc-600">Impact: {r.impact}</div>
//                 <div className="mt-1">{r.mitigation}</div>
//               </div>
//             ))}
//           </div>
//         </Section>

//         <Section title="Next Steps">
//           <List items={data.nextSteps} />
//         </Section>
//       </div>
//     </div>
//   );
// }
"use client";

import { useState } from "react";
import {
  Container,
  Paper,
  Title,
  Text,
  Group,
  Button,
  Stack,
  List,
  Divider,
  Badge,
  SimpleGrid,
} from "@mantine/core";

export default function ScopeEditor({
  scopeId,
  initialGeneratedJson,
  initialEditedJson,
}: {
  scopeId: string;
  initialGeneratedJson: any;
  initialEditedJson: any;
}) {
  const [view, setView] = useState<"generated" | "edited">("generated");
  const data = view === "generated" ? initialGeneratedJson : initialEditedJson;

  if (!data) {
    return (
      <Container size="md" py="xl">
        <Text c="dimmed">No scope document found.</Text>
      </Container>
    );
  }

  const Section = ({
    title,
    children,
  }: {
    title: string;
    children: React.ReactNode;
  }) => (
    <Paper withBorder radius="md" p="lg">
      <Title order={3} mb="sm">
        {title}
      </Title>
      {children}
    </Paper>
  );

  const StringList = ({ items }: { items?: string[] }) => {
    if (!items?.length) return <Text c="dimmed">None</Text>;
    return (
      <List spacing="xs">
        {items.map((x, i) => (
          <List.Item key={i}>{x}</List.Item>
        ))}
      </List>
    );
  };

  return (
    <Container size="lg" py="xl">
      <Group justify="space-between" mb="lg" align="flex-start">
        <div>
          <Title order={1}>{data.projectTitle ?? "Scope"}</Title>
          <Group gap="xs" mt={6}>
            <Badge variant="light">Scope</Badge>
            <Text size="sm" c="dimmed">
              {scopeId}
            </Text>
          </Group>
        </div>

        <Group>
          <Button
            variant={view === "generated" ? "filled" : "light"}
            onClick={() => setView("generated")}
          >
            Generated
          </Button>
          <Button
            variant={view === "edited" ? "filled" : "light"}
            onClick={() => setView("edited")}
          >
            Edited
          </Button>
        </Group>
      </Group>

      <Stack gap="md">
        <Section title="Executive Summary">
          <Text>{data.executiveSummary}</Text>
        </Section>

        <Section title="Problem Statement">
          <Text>{data.problemStatement}</Text>
        </Section>

        <Section title="Goals">
          <StringList items={data.goals} />
        </Section>

        <SimpleGrid cols={{ base: 1, md: 2 }} spacing="md">
          <Section title="MVP Features">
            <StringList items={data.mvp?.features} />
          </Section>

          <Section title="Phase 2 Features">
            <StringList items={data.phase2?.features} />
          </Section>
        </SimpleGrid>

        <Section title="Timeline">
          <Stack gap="sm">
            {(data.timeline ?? []).map((t: any, i: number) => (
              <Paper key={i} withBorder radius="md" p="md">
                <Group justify="space-between" mb={6}>
                  <Text fw={600}>{t.phase}</Text>
                  <Badge variant="outline">{t.durationWeeks} weeks</Badge>
                </Group>
                <Divider my="sm" />
                <StringList items={t.whatHappens} />
              </Paper>
            ))}
          </Stack>
        </Section>

        <Section title="Risks">
          <Stack gap="sm">
            {(data.risks ?? []).map((r: any, i: number) => (
              <Paper key={i} withBorder radius="md" p="md">
                <Group justify="space-between" mb={6}>
                  <Text fw={600}>{r.risk}</Text>
                  <Badge variant="light">{r.impact}</Badge>
                </Group>
                <Text>{r.mitigation}</Text>
              </Paper>
            ))}
          </Stack>
        </Section>

        <Section title="Next Steps">
          <StringList items={data.nextSteps} />
        </Section>
      </Stack>
    </Container>
  );
}
