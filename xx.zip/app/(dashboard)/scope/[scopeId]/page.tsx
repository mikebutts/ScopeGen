// /app/(dashboard)/scope/[scopeId]/page.tsx
import ScopeEditor from "@/components/scope/ScopeEditor";

type PageProps = {
  params: Promise<{ scopeId: string }>;
};

export default async function ScopePage({ params }: PageProps) {
  const { scopeId } = await params;

  // Server-side fetch to your own API
  const res = await fetch(
    `${process.env.NEXT_PUBLIC_APP_URL}/api/scope/${scopeId}`,
    {
      cache: "no-store",
    }
  );

  const data = await res.json().catch(() => ({}));

  return (
    <ScopeEditor
      scopeId={scopeId}
      initialGeneratedJson={data?.scopeDoc?.generatedJson}
      initialEditedJson={data?.scopeDoc?.editedJson}
    />
  );
}
