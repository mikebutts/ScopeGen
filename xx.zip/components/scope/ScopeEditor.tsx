"use client";

import * as React from "react";

type ScopeEditorProps = {
  // pass either one; this component will display what it gets
  scopeId?: string;
  initialGeneratedJson?: any;
  initialEditedJson?: any;
};

export default function ScopeEditor({
  scopeId,
  initialGeneratedJson,
  initialEditedJson,
}: ScopeEditorProps) {
  const [tab, setTab] = React.useState<"generated" | "edited">("generated");

  const data = tab === "generated" ? initialGeneratedJson : initialEditedJson;

  return (
    <div style={{ padding: 16 }}>
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>
          Scope {scopeId ? `• ${scopeId}` : ""}
        </h1>

        <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
          <button
            onClick={() => setTab("generated")}
            style={{
              padding: "6px 10px",
              borderRadius: 8,
              border: "1px solid #ddd",
              background: tab === "generated" ? "#eee" : "white",
              cursor: "pointer",
            }}
          >
            Generated JSON
          </button>
          <button
            onClick={() => setTab("edited")}
            style={{
              padding: "6px 10px",
              borderRadius: 8,
              border: "1px solid #ddd",
              background: tab === "edited" ? "#eee" : "white",
              cursor: "pointer",
            }}
          >
            Edited JSON
          </button>
        </div>
      </div>

      <p style={{ color: "#666", marginTop: 8 }}>
        This is a basic viewer. Next step is to render this into a nice Scope
        document UI and add edit/save.
      </p>

      <pre
        style={{
          marginTop: 16,
          padding: 16,
          borderRadius: 12,
          border: "1px solid #eee",
          background: "#fafafa",
          overflowX: "auto",
          maxHeight: "70vh",
        }}
      >
        {JSON.stringify(data ?? {}, null, 2)}
      </pre>
    </div>
  );
}
