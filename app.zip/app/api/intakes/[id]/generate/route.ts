import { NextResponse } from "next/server";
import mongoose from "mongoose";

import { connectToDB } from "@/lib/db";
import { requireUserId } from "@/lib/auth";
import ProjectIntake from "@/models/ProjectIntake";
import ScopeDoc from "@/models/ScopeDoc";
import { serializeMongo } from "@/lib/serialize";

// TODO: replace with your actual AI helper
// import { generateScopeMarkdown } from "@/lib/ai/generateScope";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(_req: Request, { params }: Ctx) {
  const { userId, error } = await requireUserId();
  if (error) return error;

  const p = await params;
  if (!p?.id) {
    return NextResponse.json({ error: "Missing id" }, { status: 400 });
  }

  const id = p.id;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  await connectToDB();

  // ✅ Intake must belong to user
  const intake = await ProjectIntake.findOne({ _id: id, userId }).lean();
  if (!intake) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  // 1) Build prompt input from intake
  const input = {
    projectName: intake.projectName,
    industry: intake.industry,
    projectType: intake.projectType,
    primaryGoal: intake.primaryGoal,
    description: intake.description,
    userTypes: intake.userTypes,
    roles: intake.roles,
    features: intake.features,
    deadline: intake.deadline,
    budgetRange: intake.budgetRange,
    proposalStyle: intake.proposalStyle,
    includePricing: intake.includePricing,
    includeTechStack: intake.includeTechStack,
    includeTimeline: intake.includeTimeline,
  };

  // 2) Call AI (placeholder)
  // const markdown = await generateScopeMarkdown(input);

  const markdown = `# Scope of Work\n\n**Project:** ${input.projectName}\n\n(placeholder — wire AI next)`;

  // 3) Save ScopeDoc
  const scopeDoc = await ScopeDoc.create({
    userId,
    projectId: id,
    content: markdown,
    status: "generated",
  });

  return NextResponse.json({
    scopeDoc: serializeMongo(scopeDoc),
  });
}
